# imporattion des biblios
from __future__ import division

import time
import sqlite3

import pygame
import random
from os import path

# Connexion à la base de donnée
con = sqlite3.connect('database/spaceData.db')
cur = con.cursor()

# les dossiers
img_dir = path.join(path.dirname(__file__), 'assets')
son_dir = path.join(path.dirname(__file__), 'sounds')

# Les constantes
WIDTH = 1281
HEIGHT = 720
FPS = 60 #Frame per seconds
SPEED = 120
POWERUP_TIME = 5000
BAR_LENGTH = 100
BAR_HEIGHT = 20

# Les couleurs
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)
BROWN = (68, 42, 0)

###############################

pygame.init() #initialiser tous les modules de pygame
pygame.joystick.init() # initialiser la gestion de mannette
pygame.mixer.init()  # initialiser la gestion des sons
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Space Shooter")
clock = pygame.time.Clock()

###############################

if pygame.joystick.get_count() > 0:
    joystick = pygame.joystick.Joystick(0);
    joystick.init()
    print("Manette détecté: ", joystick.get_name())
    print("Nombre d'axes: ", joystick.get_numaxes())
    print("Nombre de boutons: ", joystick.get_numbuttons())
else:
    print("Aucun manette détecté")

###############################

loadLoop = True
start_time = None

last_score = None
last_level = None
last_nick = None

score_page = False

def home():
    global screen
    global score_page
    global menu_display

    pygame.mixer.music.load(path.join(son_dir, "menu.mp3"))
    pygame.mixer.music.play(-1)

    title = pygame.image.load(path.join(img_dir, "main.png")).convert()
    title = pygame.transform.scale(title, (WIDTH, HEIGHT), screen)

    play_button = pygame.image.load("assets/btn_play.png")
    play_button_rect = play_button.get_rect()
    play_button_rect.x = WIDTH / 2 - play_button.get_width() - 115
    play_button_rect.y = HEIGHT / 1.6

    light = pygame.image.load("assets/light.png")
    light.set_colorkey((40,20,58))
    x = WIDTH / 2 - light.get_width() - 104
    cursor = 1
    y = HEIGHT / 1.6 - 10

    score_button = pygame.image.load("assets/btn_score.png")
    score_button_rect = score_button.get_rect()
    score_button_rect.x = WIDTH / 2 - score_button.get_width()/2
    score_button_rect.y = HEIGHT / 1.6

    quit_button = pygame.image.load("assets/btn_quit.png")
    quit_button_rect = quit_button.get_rect()
    quit_button_rect.x = WIDTH / 2 + 115
    quit_button_rect.y = HEIGHT / 1.6

    screen.blit(title, (0, 0))
    pygame.display.update()

    while True:
        ev = pygame.event.poll()
        if ev.type == pygame.KEYDOWN: #clavier
            if ev.key == pygame.K_RETURN:
                if cursor == 1: # curseur au boutton jouer
                    click_sound.play()
                    break
                elif cursor == 2: # curseur au boutton score
                    click_sound.play()
                    score_page = True
                    break
                elif cursor == 3: # curseur au boutton quitter
                    click_sound.play()
                    pygame.quit()
                    quit()
            if ev.key == pygame.K_RIGHT:
                if cursor == 1:
                    x = x + 217
                    cursor = 2
                elif cursor == 2:
                    x = x + 217
                    cursor = 3
                elif cursor == 3:
                    x = x - 217*2
                    cursor = 1
            if ev.key == pygame.K_LEFT:
                if cursor == 3:
                    x = x - 217
                    cursor = 2
                elif cursor == 2:
                    x = x - 217
                    cursor = 1
                elif cursor == 1:
                    x = x + 217*2
                    cursor = 3
        elif ev.type == pygame.JOYAXISMOTION:
            if ev.axis == 0: # détecté le bouton directionnel gauche/droite
                if ev.value >= 0.5:
                    if cursor == 1:
                        x = x + 217
                        cursor = 2
                    elif cursor == 2:
                        x = x + 217
                        cursor = 3
                    elif cursor == 3:
                        x = x - 217 * 2
                        cursor = 1
                elif ev.value <= -0.5:
                    if cursor == 3:
                        x = x - 217
                        cursor = 2
                    elif cursor == 2:
                        x = x - 217
                        cursor = 1
                    elif cursor == 1:
                        x = x + 217 * 2
                        cursor = 3
        elif ev.type == pygame.JOYBUTTONDOWN:
            if ev.button == 2: #détecter le boutton croix
                if cursor == 1: # curseur au boutton jouer
                    click_sound.play()
                    break
                elif cursor == 2: # curseur au boutton score
                    click_sound.play()
                    score_page = True
                    break
                elif cursor == 3: # curseur au boutton quitter
                    pygame.quit()
                    quit()
        elif ev.type == pygame.QUIT:
            pygame.quit()
            quit()
        elif ev.type == pygame.MOUSEBUTTONDOWN: #souris
            if play_button_rect.collidepoint(ev.pos):
                click_sound.play()
                break
            elif score_button_rect.collidepoint(ev.pos):
                click_sound.play()
                score_page = True
                break
            elif quit_button_rect.collidepoint(ev.pos):
                pygame.quit()
                quit()

        back = pygame.image.load(path.join(img_dir, "line.png")).convert()

        screen.blit(back, (0, 426))
        screen.blit(light, (x,y))
        screen.blit(play_button, play_button_rect)
        screen.blit(score_button, score_button_rect)
        screen.blit(quit_button, quit_button_rect)
        pygame.display.flip()

    if score_page:
        score_page = False
        score_banner = pygame.image.load("assets/score_banner.png")
        score_banner_rect = score_banner.get_rect()
        screen.blit(score_banner, score_banner_rect)

        score_list = pygame.image.load('assets/score_list.png')
        score_list_rect = score_list.get_rect()
        score_list_rect.x = WIDTH/2 - score_list.get_width()/2

        light1 = pygame.image.load('assets/light1.png')

        home_btn = pygame.image.load('assets/btn_home_3.png')
        home_btn_rect = home_btn.get_rect()
        home_btn_rect.x = WIDTH/2 - home_btn.get_width()/2
        home_btn_rect.y = HEIGHT - 120
        screen.blit(light1, (home_btn_rect.x-11, home_btn_rect.y-6))
        screen.blit(home_btn, home_btn_rect)

        req = "SELECT nickname, score, level FROM scores ORDER BY score DESC"
        resultat = cur.execute(req)

        i = 0
        number = 1
        for row in resultat:
            score_list_rect.y = (HEIGHT/5) + i
            screen.blit(score_list, score_list_rect)
            draw_text_brown(screen, str(number), 40, score_list_rect.x+32, score_list_rect.y +12, 'FUTURAH.ttf')
            draw_text(screen, f'{row[0]}', 35, score_list_rect.x+190, score_list_rect.y +20, 'FUTURAH.ttf')
            draw_text(screen, f'{row[1]}', 28, score_list_rect.x + 460, score_list_rect.y + 20, 'FUTURAH.ttf')
            draw_text(screen, f'Level {row[2]}', 28, score_list_rect.x + 665, score_list_rect.y + 20, 'FUTURAH.ttf')
            i += 90
            number += 1
            if number == 6:
                break

        pygame.display.update()

        while True:
            ev = pygame.event.poll()
            if ev.type == pygame.KEYDOWN:
                if ev.key == pygame.K_RETURN:
                    click_sound.play()
                    home()
                    break
            elif ev.type == pygame.QUIT:
                pygame.quit()
                quit()
            elif ev.type == pygame.MOUSEBUTTONDOWN:
                if home_btn_rect.collidepoint(ev.pos):
                    click_sound.play()
                    home()
                    break
            elif ev.type == pygame.JOYBUTTONDOWN:
                if ev.button == 2:  # détecter le boutton croix
                    click_sound.play()
                    home()
                    break
    else:
        wait = pygame.image.load("assets/wait_nick.png")
        wait_rect = wait.get_rect()
        screen.blit(wait, wait_rect)

        btn_valid = pygame.image.load("assets/btn_valid.png")
        btn_valid_rect = btn_valid.get_rect()
        btn_valid_rect.x = (WIDTH/2)-75
        btn_valid_rect.y = HEIGHT/2 + 10

        light3 = pygame.image.load('assets/light3.png')

        screen.blit(light3, (btn_valid_rect.x-13, btn_valid_rect.y-16))
        screen.blit(btn_valid, btn_valid_rect)

        font = pygame.font.Font('fonts/FUTURAH.ttf', 32)
        input_box = pygame.Rect((WIDTH/2)-150, HEIGHT/2.3, 350, 50)
        color = pygame.Color('white')
        text = ''
        pygame.display.update()

        while True:
            ev = pygame.event.poll()
            if ev.type == pygame.KEYDOWN:
                if ev.key == pygame.K_RETURN:
                    click_sound.play()
                    print(text)
                    if text != '' :
                        break
                elif ev.key == pygame.K_BACKSPACE:
                    text = text[:-1]
                else:
                    if len(text) <= 8 :
                        text += ev.unicode.upper()
            elif ev.type == pygame.JOYBUTTONDOWN:
                if ev.button == 2:  # détecter le boutton croix
                    click_sound.play()
                    print(text)
                    if text != '':
                        break
            elif ev.type == pygame.QUIT:
                pygame.quit()
                quit()
            elif ev.type == pygame.MOUSEBUTTONDOWN:
                if btn_valid_rect.collidepoint(ev.pos):
                    click_sound.play()
                    print(text)
                    if text != '' :
                        break

            pygame.draw.rect(screen, color, input_box, 2, 10)
            txt_surface = font.render(text, True, color)
            screen.blit(txt_surface, (input_box.x + 20, input_box.y + 5))
            pygame.display.flip()
            global last_nick
            last_nick = text

        banner = pygame.image.load("assets/main.png")
        banner_rect = banner.get_rect()
        screen.blit(banner, banner_rect)

        border_rect = [410, 460, 450, 40]
        inner_rect = [415, 465, 0, 30]

        while loadLoop:
            clock.tick(FPS)

            if inner_rect[2] < 439:
                inner_rect[2] += SPEED / FPS
            else:
                break

            pygame.draw.rect(screen, WHITE, border_rect, 3)
            pygame.draw.rect(screen, WHITE, (inner_rect[0], inner_rect[1], int(inner_rect[2]), inner_rect[3]))
            pygame.display.flip()
            global start_time
            start_time = time.time()

    menu_display = False
    pygame.display.update()

go_home = False

def saveScore():
    old_player = False
    req1 = "SELECT nickname FROM scores"
    result = cur.execute(req1)
    for row in result:
        if last_nick == row[0]:
            old_player = True

    if old_player:
        req = f"UPDATE scores set score = {last_score}, level = {last_level} WHERE nickname = '{last_nick}'"
    else:
        req = f"INSERT INTO scores (nickname, score, level) VALUES ('{last_nick}', {last_score}, {last_level})"
    cur.execute(req)
    con.commit()


def gameOver():
    saveScore()
    global screen

    pygame.mixer.music.load(path.join(son_dir, "menu.mp3"))
    pygame.mixer.music.play(-1)

    title = pygame.image.load(path.join(img_dir, "gameOver.png")).convert()
    title = pygame.transform.scale(title, (WIDTH, HEIGHT), screen)

    light = pygame.image.load("assets/light2.png")
    light.set_colorkey((72, 35, 104))
    x = WIDTH / 2 - light.get_width() - 94
    cursor = 1
    y = HEIGHT / 1.6 - 10

    play_button = pygame.image.load("assets/btn_play_2.png")
    play_button_rect = play_button.get_rect()
    play_button_rect.x = WIDTH / 2 - play_button.get_width() - 100
    play_button_rect.y = HEIGHT / 1.6

    home_button = pygame.image.load("assets/btn_home.png")
    home_button_rect = home_button.get_rect()
    home_button_rect.x = WIDTH / 2 - home_button.get_width() / 2
    home_button_rect.y = HEIGHT / 1.6

    quit_button = pygame.image.load("assets/btn_quit_2.png")
    quit_button_rect = quit_button.get_rect()
    quit_button_rect.x = WIDTH / 2 + 97
    quit_button_rect.y = HEIGHT / 1.6

    last_score_bar = pygame.image.load("assets/last_score_bar.png")
    last_score_bar_rect = last_score_bar.get_rect()
    last_score_bar_rect.x = (WIDTH / 2) - last_score_bar.get_width()
    last_score_bar_rect.y = (HEIGHT / 2) - 50

    last_level_bar = pygame.image.load("assets/last_level_bar.png")
    last_level_bar_rect = last_level_bar.get_rect()
    last_level_bar_rect.x = (WIDTH / 2)
    last_level_bar_rect.y = (HEIGHT / 2) - 50

    global last_score
    global last_level

    screen.blit(title, (0, 0))
    screen.blit(last_score_bar, last_score_bar_rect)
    draw_text(screen, str(last_score), 35, last_score_bar_rect.x + 150, last_score_bar_rect.y + 28, 'FUTURAH.ttf')
    screen.blit(last_level_bar, last_level_bar_rect)
    draw_text(screen, 'Level ' + str(last_level), 35, last_level_bar_rect.x + 90, last_level_bar_rect.y + 28,
              'FUTURAH.ttf')
    pygame.display.update()

    while True:
        global go_home
        ev = pygame.event.poll()
        if ev.type == pygame.KEYDOWN:
            if ev.key == pygame.K_RETURN:
                if cursor == 1: # curseur au boutton rejouer
                    click_sound.play()
                    break
                elif cursor == 2: # curseur au boutton home
                    click_sound.play()
                    go_home = True
                    break
                elif cursor == 3: # curseur au boutton quitter
                    pygame.quit()
                    quit()
            if ev.key == pygame.K_q:
                pygame.quit()
                quit()
            if ev.key == pygame.K_RIGHT:
                if cursor == 1:
                    x = x + 197
                    cursor = 2
                elif cursor == 2:
                    x = x + 197
                    cursor = 3
                elif cursor == 3:
                    x = x - 197*2
                    cursor = 1
            if ev.key == pygame.K_LEFT:
                if cursor == 3:
                    x = x - 197
                    cursor = 2
                elif cursor == 2:
                    x = x - 197
                    cursor = 1
                elif cursor == 1:
                    x = x + 197*2
                    cursor = 3
        elif ev.type == pygame.JOYAXISMOTION:
            if ev.axis == 0: # détecté le bouton directionnel gauche/droite
                if ev.value >= 0.5:
                    if cursor == 1:
                        x = x + 197
                        cursor = 2
                    elif cursor == 2:
                        x = x + 197
                        cursor = 3
                    elif cursor == 3:
                        x = x - 197 * 2
                        cursor = 1
                elif ev.value <= -0.5:
                    if cursor == 3:
                        x = x - 197
                        cursor = 2
                    elif cursor == 2:
                        x = x - 197
                        cursor = 1
                    elif cursor == 1:
                        x = x + 197 * 2
                        cursor = 3
        elif ev.type == pygame.JOYBUTTONDOWN:
            if ev.button == 2: #détecter le boutton croix
                if cursor == 1: # curseur au boutton rejouer
                    click_sound.play()
                    break
                elif cursor == 2: # curseur au boutton home
                    click_sound.play()
                    go_home = True
                    break
                elif cursor == 3: # curseur au boutton quitter
                    pygame.quit()
                    quit()
        elif ev.type == pygame.QUIT:
            pygame.quit()
            quit()
        elif ev.type == pygame.MOUSEBUTTONDOWN:
            if play_button_rect.collidepoint(ev.pos):
                click_sound.play()
                break
            elif home_button_rect.collidepoint(ev.pos):
                click_sound.play()
                go_home = True
                break
            elif quit_button_rect.collidepoint(ev.pos):
                click_sound.play()
                pygame.quit()
                quit()

        back = pygame.image.load(path.join(img_dir, "line.png")).convert()

        screen.blit(back, (0, 426))
        screen.blit(light, (x, y))
        screen.blit(play_button, play_button_rect)
        screen.blit(quit_button, quit_button_rect)
        screen.blit(home_button, home_button_rect)
        pygame.display.flip()

    banner = pygame.image.load("assets/gameOver.png")
    banner_rect = banner.get_rect()
    screen.blit(banner, banner_rect)

    border_rect = [410, 460, 450, 40]
    inner_rect = [415, 465, 0, 30]

    while loadLoop:
        if go_home:
            global menu_display
            menu_display = True
            break

        clock.tick(FPS)

        if inner_rect[2] < 439:
            inner_rect[2] += SPEED / FPS
        else:
            break

        pygame.draw.rect(screen, WHITE, border_rect, 3)
        pygame.draw.rect(screen, WHITE, (inner_rect[0], inner_rect[1], int(inner_rect[2]), inner_rect[3]))
        pygame.display.flip()
        global start_time
        start_time = time.time()

    pygame.display.update()


def nextLevel():
    saveScore()
    global screen

    pygame.mixer.music.load(path.join(son_dir, "menu.mp3"))
    pygame.mixer.music.play(-1)

    title = pygame.image.load(path.join(img_dir, "nextLevel.png")).convert()
    title = pygame.transform.scale(title, (WIDTH, HEIGHT), screen)

    light = pygame.image.load("assets/light4.png")
    light.set_colorkey((57, 26, 83))
    x = WIDTH / 2 - light.get_width() - 87
    cursor = 1
    y = HEIGHT / 1.6 + 17

    play_button = pygame.image.load("assets/btn_continue.png")
    play_button_rect = play_button.get_rect()
    play_button_rect.x = WIDTH / 2 - play_button.get_width() - 100
    play_button_rect.y = HEIGHT / 1.5

    home_button = pygame.image.load("assets/btn_home_3.png")
    home_button_rect = home_button.get_rect()
    home_button_rect.x = WIDTH / 2 - home_button.get_width() / 2
    home_button_rect.y = HEIGHT / 1.5

    quit_button = pygame.image.load("assets/btn_quit_3.png")
    quit_button_rect = quit_button.get_rect()
    quit_button_rect.x = WIDTH / 2 + 98
    quit_button_rect.y = HEIGHT / 1.5

    last_score_bar = pygame.image.load("assets/last_score_bar.png")
    last_score_bar_rect = last_score_bar.get_rect()
    last_score_bar_rect.x = (WIDTH / 2) - last_score_bar.get_width() / 2
    last_score_bar_rect.y = (HEIGHT / 2) - 10

    screen.blit(title, (0, 0))
    draw_text(screen, f'Vous avez achevé le LEVEL {last_level}', 40, (WIDTH / 2) + 16, (HEIGHT / 2.6), 'FUTURAH.ttf')
    screen.blit(last_score_bar, last_score_bar_rect)
    draw_text(screen, str(last_score), 40, last_score_bar_rect.x + 155, last_score_bar_rect.y + 25, 'FUTURAH.ttf')

    pygame.display.update()

    while True:
        global go_home
        ev = pygame.event.poll()
        if ev.type == pygame.KEYDOWN:
            if ev.key == pygame.K_RETURN:
                click_sound.play()
                break
            if ev.key == pygame.K_q:
                pygame.quit()
                quit()
            if ev.key == pygame.K_RIGHT:
                if cursor == 1:
                    x = x + 196
                    cursor = 2
                elif cursor == 2:
                    x = x + 196
                    cursor = 3
                elif cursor == 3:
                    x = x - 196*2
                    cursor = 1
            if ev.key == pygame.K_LEFT:
                if cursor == 3:
                    x = x - 196
                    cursor = 2
                elif cursor == 2:
                    x = x - 196
                    cursor = 1
                elif cursor == 1:
                    x = x + 196*2
                    cursor = 3
        elif ev.type == pygame.JOYAXISMOTION:
            if ev.axis == 0: # détecté le bouton directionnel gauche/droite
                if ev.value >= 0.5:
                    if cursor == 1:
                        x = x + 196
                        cursor = 2
                    elif cursor == 2:
                        x = x + 196
                        cursor = 3
                    elif cursor == 3:
                        x = x - 196 * 2
                        cursor = 1
                elif ev.value <= -0.5:
                    if cursor == 3:
                        x = x - 196
                        cursor = 2
                    elif cursor == 2:
                        x = x - 196
                        cursor = 1
                    elif cursor == 1:
                        x = x + 196 * 2
                        cursor = 3
        elif ev.type == pygame.JOYBUTTONDOWN:
            if ev.button == 2: #détecter le boutton croix
                if cursor == 1: # curseur au boutton continuer
                    click_sound.play()
                    break
                elif cursor == 2: # curseur au boutton home
                    click_sound.play()
                    go_home = True
                    break
                elif cursor == 3: # curseur au boutton quitter
                    pygame.quit()
                    quit()
        elif ev.type == pygame.QUIT:
            pygame.quit()
            quit()
        elif ev.type == pygame.MOUSEBUTTONDOWN:
            if play_button_rect.collidepoint(ev.pos):
                click_sound.play()
                break
            elif home_button_rect.collidepoint(ev.pos):
                click_sound.play()
                go_home = True
                break
            elif quit_button_rect.collidepoint(ev.pos):
                pygame.quit()
                quit()

        back = pygame.image.load(path.join(img_dir, "line2.png")).convert()

        screen.blit(back, (0, 446))
        screen.blit(light, (x, y))
        screen.blit(play_button, play_button_rect)
        screen.blit(quit_button, quit_button_rect)
        screen.blit(home_button, home_button_rect)
        pygame.display.update()

    banner = pygame.image.load("assets/nextLevel.png")
    banner_rect = banner.get_rect()
    screen.blit(banner, banner_rect)
    draw_text(screen, f'Preparez-vous pour le LEVEL {last_level + 1}', 40, (WIDTH / 2) + 16, (HEIGHT / 2),
              'FUTURAH.ttf')

    border_rect = [410, 460, 450, 40]
    inner_rect = [415, 465, 0, 30]

    while loadLoop:
        if go_home:
            global menu_display
            menu_display = True
            break

        clock.tick(FPS)

        if inner_rect[2] < 439:
            inner_rect[2] += SPEED / FPS
        else:
            break

        pygame.draw.rect(screen, WHITE, border_rect, 3)
        pygame.draw.rect(screen, WHITE, (inner_rect[0], inner_rect[1], int(inner_rect[2]), inner_rect[3]))
        pygame.display.flip()
        global start_time
        start_time = time.time()

    pygame.display.update()


def draw_text(surf, text, size, x, y, family):
    font = pygame.font.Font(f'fonts/{family}', size)

    text_surface = font.render(text, True, WHITE)
    text_rect = text_surface.get_rect()
    text_rect.midtop = (x, y)
    surf.blit(text_surface, text_rect)

def draw_text_brown(surf, text, size, x, y, family):
    font = pygame.font.Font(f'fonts/{family}', size)

    text_surface = font.render(text, True, BROWN)
    text_rect = text_surface.get_rect()
    text_rect.midtop = (x, y)
    surf.blit(text_surface, text_rect)

def draw_power_bar(surface, x, y, pct): # pct: Fihenan'ny powerbar
    surface.blit(power_bar, power_bar_rect)
    pct = max(pct, 0)
    fill = (pct / 100) * BAR_LENGTH
    fill_rect = pygame.Rect(x, y, fill, BAR_HEIGHT)
    pygame.draw.rect(surface, YELLOW, fill_rect)
    surface.blit(power_icon, power_bar_rect)


def draw_score(surface, x, y, scr):
    surface.blit(score_bar, (x, y))
    draw_text(screen, str(scr), 25, x + 115, 15, 'GamePlayed.otf')


def draw_level(surface, x, y, lvl):
    text = 'LEVEL ' + str(lvl)
    draw_text(surface, text, 30, x, y + 10, 'GamePlayed.otf')


def draw_time(surface, x, y, duration):
    surface.blit(time_bar, (x, y))
    draw_text(screen, str(duration - int(time.time() - start_time)), 25, x + 100, y + 15, 'GamePlayed.otf')


def draw_lives(surf, x, y, lives, img):
    for i in range(lives):
        img_rect = img.get_rect()
        img_rect.x = x + 35 * i
        img_rect.y = y
        surf.blit(img, img_rect)


def newmob():
    mob_element = Mob()
    all_sprites.add(mob_element)
    mobs.add(mob_element)


class Explosion(pygame.sprite.Sprite):
    def __init__(self, center, size):
        pygame.sprite.Sprite.__init__(self)
        self.size = size
        self.image = explosion_anim[self.size][0]
        self.rect = self.image.get_rect()
        self.rect.center = center
        self.frame = 0
        self.last_update = pygame.time.get_ticks()  # nombre de millisecondes écoulée depuis le debut
        self.frame_rate = 75  # nombre de frame par seconde

    def update(self):
        now = pygame.time.get_ticks()
        if now - self.last_update > self.frame_rate:
            self.last_update = now
            self.frame += 1
            if self.frame == len(explosion_anim[self.size]):
                self.kill()
            else:
                center = self.rect.center
                self.image = explosion_anim[self.size][self.frame]
                self.rect = self.image.get_rect()
                self.rect.center = center


class Player(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image = player_img
        self.rect = self.image.get_rect()
        self.radius = 30
        self.rect.centerx = WIDTH / 2
        self.rect.bottom = HEIGHT - 30
        self.speedx = 0  # vitesse horizondale
        self.shield = 235
        self.level = 1
        self.shoot_delay = 250
        self.last_shot = pygame.time.get_ticks()
        self.lives = 3
        self.hidden = False
        self.hide_time = pygame.time.get_ticks()
        self.strength = 1
        self.strength_time = pygame.time.get_ticks()

    def update(self):
        # si le nombre de balle qui sort (strength) est superieur à deux et ca fait 5 secondes il est comme ca, decremente le de un
        if self.strength >= 2 and pygame.time.get_ticks() - self.strength_time > POWERUP_TIME:
            self.strength -= 1
            self.strength_time = pygame.time.get_ticks()

        # si le joueur est caché et le temps de son cache-cache est plus d'une seconde, reaffiche-le au centre
        if self.hidden and pygame.time.get_ticks() - self.hide_time > 1000:
            self.hidden = False
            self.rect.centerx = WIDTH / 2
            self.rect.bottom = HEIGHT - 30

        self.speedx = 0  # reinitialiser la vitesse horizontale

        # Mise à jours du deplacement gauche/droite à partir de clavier
        key_event = pygame.key.get_pressed()
        if key_event[pygame.K_LEFT]:
            self.speedx = -5
        elif key_event[pygame.K_RIGHT]:
            self.speedx = 5

        # Declachement des balles à partir de l'ESPACE du clavier
        if key_event[pygame.K_SPACE]:
            self.shoot()

        # Mise à jours du deplacement gauche/droite à partir de manette
        if pygame.joystick.get_count() > 0:
            x_axis = joystick.get_axis(0)
            if x_axis >= 0.5:
                self.speedx = 5
            elif x_axis <= -0.5:
                self.speedx = -5
        self.rect.x += self.speedx

        # Declachement des balles à partir du bouton triangle de manette
        if pygame.joystick.get_count() > 0:
            triangle_button = joystick.get_button(0)
            if triangle_button:
                self.shoot()

        # Limitation du deplacement du joueur pour qu'il ne sorte pas en dehors de l'ecran
        if self.rect.right > WIDTH:
            self.rect.right = WIDTH
        if self.rect.left < 0:
            self.rect.left = 0

        self.rect.x += self.speedx

    def shoot(self):
        now = pygame.time.get_ticks()
        if now - self.last_shot > self.shoot_delay:
            self.last_shot = now
            if self.strength == 1:
                bullet = Bullet(self.rect.centerx, self.rect.top)
                all_sprites.add(bullet)
                bullets.add(bullet)
                shooting_sound.play()
            if self.strength == 2:
                bullet1 = Bullet(self.rect.left, self.rect.centery)
                bullet2 = Bullet(self.rect.right, self.rect.centery)
                all_sprites.add(bullet1)
                all_sprites.add(bullet2)
                bullets.add(bullet1)
                bullets.add(bullet2)
                shooting_sound.play()
            if self.strength >= 3:
                bullet1 = Bullet(self.rect.left, self.rect.centery)
                bullet2 = Bullet(self.rect.right, self.rect.centery)
                bullet3 = Bullet(self.rect.centerx, self.rect.top)
                all_sprites.add(bullet1)
                all_sprites.add(bullet2)
                all_sprites.add(bullet3)
                bullets.add(bullet1)
                bullets.add(bullet2)
                bullets.add(bullet3)
                shooting_sound.play()

    def powerup(self):
        self.strength += 1
        self.strength_time = pygame.time.get_ticks()

    def hide(self):
        self.hidden = True
        self.hide_time = pygame.time.get_ticks()
        self.rect.center = (WIDTH / 2, HEIGHT + 200)


# Definition des meteorites
class Mob(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image_orig = random.choice(meteor_images)
        self.image_orig.set_colorkey(BLACK) # Considerer la couleur noire comme transparent
        self.image = self.image_orig.copy()
        self.rect = self.image.get_rect()
        self.radius = int(self.rect.width * .90 / 2) #Definir la rayon de cercle qui entour la meteorite
        self.rect.x = random.randrange(0, WIDTH - self.rect.width) # Randomizer la position initial en x
        self.rect.y = random.randrange(-150, -100) # Randomizer la position initial en y
        self.speedy = random.randrange(5, 20)  # Randomizer la vitesse de la meteorite en y
        self.speedx = random.randrange(-3, 3)  # Randomizer la vitesse de la meteorite en x

        # Ajouter une rotation
        self.rotation = 0
        self.rotation_speed = random.randrange(-8, 8)
        self.last_update = pygame.time.get_ticks()  # Temps ou la rotation commence

    def rotate(self):
        time_now = pygame.time.get_ticks()
        if time_now - self.last_update > 50:  # en millisecondes
            self.last_update = time_now
            self.rotation = (self.rotation + self.rotation_speed) % 360
            new_image = pygame.transform.rotate(self.image_orig, self.rotation)
            old_center = self.rect.center
            self.image = new_image
            self.rect = self.image.get_rect()
            self.rect.center = old_center

    def update(self):
        self.rotate()
        self.rect.x += self.speedx
        self.rect.y += self.speedy

        # Initialiser la position et la vitesse de la meteorite au moment ou elle est au point de sortir l'ecran
        if (self.rect.top > HEIGHT + 10) or (self.rect.left < -25) or (self.rect.right > WIDTH + 20):
            self.rect.x = random.randrange(0, WIDTH - self.rect.width)
            self.rect.y = random.randrange(-100, -40)
            self.speedy = random.randrange(1, 8)


# Definition de la powerups
class Pow(pygame.sprite.Sprite):
    def __init__(self, center):
        pygame.sprite.Sprite.__init__(self)
        self.type = random.choice(['shield', 'gun'])
        self.image = powerup_images[self.type]
        self.image.set_colorkey(BLACK)
        self.rect = self.image.get_rect()
        self.rect.center = center
        self.speedy = 2

    def update(self):
        self.rect.y += self.speedy
        # Supprime le powerup au moment ou il sort l'ecran
        if self.rect.top > HEIGHT:
            self.kill()


# Definir les balles
class Bullet(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = bullet_img
        self.image.set_colorkey(BLACK)
        self.rect = self.image.get_rect()
        self.rect.bottom = y
        self.rect.centerx = x
        self.speedy = -10

    def update(self):
        self.rect.y += self.speedy
        # Supprime la balle au moment ou il sort l'ecran
        if self.rect.bottom < 0:
            self.kill()

###################################################

background = pygame.image.load(path.join(img_dir, 'back.png')).convert()
background_rect = background.get_rect()
flou_back = pygame.image.load('assets/flou.png')
flou_back_rect = flou_back.get_rect()
flou_back_rect.y = -20
black = pygame.image.load('assets/black.png')
black_rect = black.get_rect()
black_rect.y = -20
power_bar = pygame.image.load('assets/power_bar.png')
power_bar_rect = power_bar.get_rect()
power_icon = pygame.image.load('assets/power_icon.png')
score_bar = pygame.image.load('assets/score_bar.png')
time_bar = pygame.image.load('assets/time_bar.png')
separator = pygame.image.load('assets/separator.png')

player_img = pygame.image.load('assets/ship.png')
nickname_back = pygame.image.load('assets/nickname_back.png')
player_mini_img = pygame.transform.scale(player_img, (player_img.get_width() / 3, player_img.get_height() / 3))
player_mini_img.set_colorkey(BLACK)
bullet_img = pygame.image.load(path.join(img_dir, 'laserRed16.png')).convert()
meteor_images = []
meteor_list = [
    'meteorBrown_big1.png',
    'meteorBrown_big2.png',
    'meteorBrown_med1.png',
    'meteorBrown_med3.png',
    'meteorBrown_small1.png',
    'meteorBrown_small2.png',
    'meteorBrown_tiny1.png'
]

for image in meteor_list:
    meteor_images.append(pygame.image.load(path.join(img_dir, image)).convert())

# Explosion des meteorite
explosion_anim = {'lg': [], 'sm': [], 'player': []}

for i in range(9):  # 0 à 8 inclus
    filename = f'boom{i}.png'
    img = pygame.image.load(f'{img_dir}/{filename}')

    # redimensionner les explosions
    img_lg = pygame.transform.scale(img, (75, 75))
    explosion_anim['lg'].append(img_lg)
    img_sm = pygame.transform.scale(img, (32, 32))
    explosion_anim['sm'].append(img_sm)

    # explosion de joueur
    filename = f'paw{i}.png'
    img = pygame.image.load(f'{img_dir}/{filename}')
    explosion_anim['player'].append(img)

# Chargement des powerups
powerup_images = {}
powerup_images['gun'] = pygame.image.load(path.join(img_dir, 'shield_gold.png')).convert()
powerup_images['shield'] = pygame.image.load(path.join(img_dir, 'bolt_gold.png')).convert()

###################################################

shooting_sound = pygame.mixer.Sound(path.join(son_dir, 'pew.wav'))
click_sound = pygame.mixer.Sound(path.join(son_dir, 'click.mp3'))

expl_sounds = []
expl_sounds.append(pygame.mixer.Sound(path.join(son_dir, 'explosion1.wav')))
expl_sounds.append(pygame.mixer.Sound(path.join(son_dir, 'explosion2.wav')))

pygame.mixer.music.set_volume(0.2)
player_die_sound = pygame.mixer.Sound(path.join(son_dir, 'rumble1.ogg'))

#############################

# Game loop
running = True
menu_display = True
game_over = False
next_level = False

while running:
    if game_over:
        gameOver()
        game_over = False

        pygame.mixer.music.stop()
        pygame.mixer.music.set_volume(1)
        pygame.mixer.music.load(path.join(son_dir, 'action.mp3'))
        pygame.mixer.music.play(-1)

        all_sprites = pygame.sprite.Group()
        player = Player()
        all_sprites.add(player)

        mobs = pygame.sprite.Group()
        for i in range(8):
            newmob()

        bullets = pygame.sprite.Group()
        powerups = pygame.sprite.Group()

        score = 0

    if next_level:
        nextLevel()
        next_level = False

        pygame.mixer.music.stop()
        pygame.mixer.music.set_volume(1)
        pygame.mixer.music.load(path.join(son_dir, 'action.mp3'))
        pygame.mixer.music.play(-1)

        all_sprites = pygame.sprite.Group()
        player = Player()
        player.level = last_level + 1
        score = last_score
        all_sprites.add(player)

        # spawn a group of mob
        mobs = pygame.sprite.Group()
        for i in range(8*player.level):
            newmob()

        # group for bullets
        bullets = pygame.sprite.Group()
        powerups = pygame.sprite.Group()

    if menu_display:
        home()
        menu_display = False

        pygame.mixer.music.stop()
        pygame.mixer.music.set_volume(1)
        pygame.mixer.music.load(path.join(son_dir, 'action.mp3'))
        pygame.mixer.music.play(-1)

        all_sprites = pygame.sprite.Group()
        player = Player()
        all_sprites.add(player)

        # spawn a group of mob
        mobs = pygame.sprite.Group()
        for i in range(8):
            newmob()

        # group for bullets
        bullets = pygame.sprite.Group()
        powerups = pygame.sprite.Group()

        # Score board variable
        score = 0

    clock.tick(FPS)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                running = False

    all_sprites.update()

    # Verifier si les lasers sont en cotact avec les meteorites
    hits = pygame.sprite.groupcollide(mobs, bullets, True, True)  # mob de mobs et bullet de bullets sont supprimé
    for hit in hits:
        score += 50 - hit.radius  # pour avoir differents points selon le taille de meteorite
        if score < 0:
            score = 0

        random.choice(expl_sounds).play()
        expl = Explosion(hit.rect.center, 'lg')
        all_sprites.add(expl)
        if random.random() > 0.9:
            pow = Pow(hit.rect.center)
            all_sprites.add(pow)
            powerups.add(pow)
        newmob()  # genère un nouveau meteorite

    #########################

    # Verifier si le joueur est en contact avec la meteorite
    hits = pygame.sprite.spritecollide(player, mobs, True, pygame.sprite.collide_circle) # retourne une liste
    for hit in hits:
        player.shield -= hit.radius * 2
        expl = Explosion(hit.rect.center, 'sm')
        all_sprites.add(expl)
        newmob()
        if player.shield <= 0:
            player_die_sound.play()
            death_explosion = Explosion(player.rect.center, 'player')
            all_sprites.add(death_explosion)
            player.hide()
            player.lives -= 1
            player.shield = 235

    # si le player gagne un powerup
    hits = pygame.sprite.spritecollide(player, powerups, True)
    for hit in hits:
        if hit.type == 'shield':
            player.shield += random.randrange(10, 30)
            if player.shield >= 235:
                player.shield = 235
        if hit.type == 'gun':
            player.powerup()

    # si le joueur meurt et l'explosion est terminée, gameover
    if player.lives == 0 and not death_explosion.alive():
        last_score = score
        last_level = player.level
        game_over = True

    if int(time.time() - start_time) == 60:
        last_score = score
        last_level = player.level
        next_level = True

    screen.blit(background, background_rect)
    screen.blit(flou_back, flou_back_rect)

    all_sprites.draw(screen)
    screen.blit(black, black_rect)
    screen.blit(separator, (0, 57))
    screen.blit(nickname_back, (20, 80))
    draw_text(screen, last_nick , 25, 100, 82, 'FUTURAH.ttf')

    draw_power_bar(screen, 63, 20, player.shield)
    draw_score(screen, (WIDTH / 3.5), 0, score)
    draw_level(screen, (WIDTH / 1.8), 0, player.level)
    draw_time(screen, (WIDTH / 1.45), 0, 60)
    draw_lives(screen, WIDTH - 135, 10, player.lives, player_mini_img)

    # Rafraichir l'ecran avec las dernières modifs
    pygame.display.flip()
